﻿
// NAME : Armanveer Singh Bopara
// STUDENT NUMBER : 000922325


// Filename: Course.cs
// Description: Represents a course within the Learning Management System. Each course has an ID, a title, and a description.
// Inputs:
//   - Id: An integer representing the unique identifier for each course.
//   - Title: A string representing the title of the course.
//   - Description: A string providing a detailed description of what the course entails.
// Processing: This model serves as a data structure without any processing logic, designed to hold information about a single course.
// Outputs: Not applicable, as this model does not generate outputs but rather is used to store and transfer course information within the system.

namespace LearningManagementProject.Models
{
    /// <summary>
    /// Represents a course with an ID, title, and description.
    /// </summary>
    public class Course
    {
        // Unique identifier for the course
        public int Id { get; set; }

        // Title of the course
        public string Title { get; set; } = string.Empty;

        // Detailed description of the course
        public string Description { get; set; } = string.Empty;
    }
}

