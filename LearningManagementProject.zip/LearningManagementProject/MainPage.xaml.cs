﻿using LearningManagementProject.Models;
using Microsoft.Maui.Controls;
using System.Collections.ObjectModel;
using System.Linq;


// NAME : Armanveer Singh Bopara
// STUDENT NUMBER : 000922325


// Filename: MainPage.xaml.cs
// Description: Code-behind for the MainPage.xaml. This class contains logic for initializing the main page,
//               handling user interactions such as adding and deleting courses, and updating the UI accordingly.
//               It interacts with the database through the DatabaseHelper class to persist courses data.

namespace LearningManagementProject
{
    public partial class MainPage : ContentPage
    {
        // A collection to store and display courses on the UI.
        // ObservableCollection is used to automatically update the UI when items are added or removed.
        public ObservableCollection<Course> Courses { get; set; }

        public MainPage()
        {
            InitializeComponent();
            DatabaseHelper.InitializeDatabase(); // Initializes the database (creates table if not exists).
            Courses = new ObservableCollection<Course>(DatabaseHelper.GetAllCourses()); // Retrieves all courses from the database.
            coursesListView.ItemsSource = Courses; // Binds the Courses collection to the ListView on the UI.
        }

        // Event handler for the "Add Course" button click.
        // Adds a new course to the database and updates the UI.
        private void OnAddCourseClicked(object sender, System.EventArgs e)
        {
            // Checks if the title and description fields are not empty.
            if (!string.IsNullOrWhiteSpace(titleEntry.Text) && !string.IsNullOrWhiteSpace(descriptionEditor.Text))
            {
                DatabaseHelper.AddCourse(titleEntry.Text, descriptionEditor.Text); // Adds the course to the database.
                Courses.Add(new Course // Adds the course to the UI collection.
                {
                    Title = titleEntry.Text,
                    Description = descriptionEditor.Text
                });

                // Clears the title and description fields after adding the course.
                titleEntry.Text = string.Empty;
                descriptionEditor.Text = string.Empty;
            }
        }

        // Event handler for the "Delete" button click in each course item.
        // Removes a course from the database and updates the UI.
        private void OnDeleteCourseClicked(object sender, System.EventArgs e)
        {
            var button = (Button)sender; // The button that was clicked.
            var course = (Course)button.CommandParameter; // Retrieves the Course object bound to the button.
            DatabaseHelper.DeleteCourse(course.Id); // Deletes the course from the database.
            Courses.Remove(course); // Removes the course from the UI collection.
        }
    }
}

