﻿using Microsoft.Data.Sqlite;
using System.Collections.Generic;
using LearningManagementProject.Models;


// NAME : Armanveer Singh Bopara
// STUDENT NUMBER : 000922325

// Filename: DatabaseHelper.cs

// Description: Facilitates database operations for the Learning Management System (LMS),
//              including the initialization of the database, addition, retrieval, and deletion of courses.
//              Utilizes SQLite for persistent data storage.

namespace LearningManagementProject
{
    public static class DatabaseHelper
    {
        // Database file path
        private const string DbPath = "Data Source=LearningManagementProject.db";

        /// <summary>
        /// Initializes the SQLite database. Creates the 'Courses' table if it does not already exist.
        /// </summary>
        public static void InitializeDatabase()
        {
            using var connection = new SqliteConnection(DbPath);
            connection.Open();

            var command = connection.CreateCommand();
            command.CommandText =
            @"
                CREATE TABLE IF NOT EXISTS Courses (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Title TEXT NOT NULL,
                    Description TEXT NOT NULL
                );
            ";
            command.ExecuteNonQuery(); // Execute the SQL command to ensure the Courses table exists.
        }

        /// <summary>
        /// Adds a new course to the 'Courses' table.
        /// </summary>
        /// <param name="title">The title of the course.</param>
        /// <param name="description">The description of the course.</param>
        public static void AddCourse(string title, string description)
        {
            using var connection = new SqliteConnection(DbPath);
            connection.Open();

            var command = connection.CreateCommand();
            command.CommandText = "INSERT INTO Courses (Title, Description) VALUES (@title, @description);";
            command.Parameters.AddWithValue("@title", title);
            command.Parameters.AddWithValue("@description", description);
            command.ExecuteNonQuery(); // Execute the SQL command to insert the new course.
        }

        /// <summary>
        /// Retrieves all courses from the 'Courses' table.
        /// </summary>
        /// <returns>A list of Course objects, each representing a course in the database.</returns>
        public static List<Course> GetAllCourses()
        {
            var courses = new List<Course>();

            using var connection = new SqliteConnection(DbPath);
            connection.Open();

            var command = connection.CreateCommand();
            command.CommandText = "SELECT Id, Title, Description FROM Courses;";

            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                courses.Add(new Course
                {
                    Id = reader.GetInt32(0), // The ID of the course.
                    Title = reader.GetString(1), // The title of the course.
                    Description = reader.GetString(2) // The description of the course.
                });
            }

            return courses; // Return the list of courses.
        }

        /// <summary>
        /// Deletes a course from the 'Courses' table based on the provided course ID.
        /// </summary>
        /// <param name="courseId">The ID of the course to delete.</param>
        public static void DeleteCourse(int courseId)
        {
            using var connection = new SqliteConnection(DbPath);
            connection.Open();

            var command = connection.CreateCommand();
            command.CommandText = "DELETE FROM Courses WHERE Id = @id;";
            command.Parameters.AddWithValue("@id", courseId);
            command.ExecuteNonQuery(); // Execute the SQL command to delete the course.
        }
    }
}
