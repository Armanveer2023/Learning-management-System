﻿using Microsoft.Extensions.Logging;
using Microsoft.Maui.Hosting;

// NAME : Armanveer Singh Bopara
// STUDENT NUMBER : 000922325

// Filename: MauiProgram.cs
// Description: Initializes and configures the .NET MAUI application. This class is the entry point of the application,
//              setting up app services, fonts, and logging. The configuration defined here is applied globally
//              throughout the application.

namespace LearningManagementProject
{
    public static class MauiProgram
    {
        /// <summary>
        /// Configures and creates the MAUI application instance.
        /// </summary>
        /// <returns>A configured MauiApp instance.</returns>
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();

            builder
                .UseMauiApp<App>() // Sets the startup class for the application.
                .ConfigureFonts(fonts =>
                {
                    // Adds custom fonts to the application. These fonts are available globally across the application.
                    fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                    fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                });

            // Adds debug logging when the application is built in DEBUG mode.
            // Useful for development to log detailed information about the app's operation.
#if DEBUG
            builder.Logging.AddDebug();
#endif

            return builder.Build(); // Builds and returns the configured MauiApp instance.
        }
    }
}
